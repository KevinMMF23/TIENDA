class Producto:
    def __init__(self, id, nombre, imagen, precio):
        self.id = id
        self.nombre = nombre
        self.imagen = imagen
        self.precio = precio
